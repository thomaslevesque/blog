﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoSortGridView
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            People = new List<Person>
            {
                new Person { LastName = "Jones", FirstName = "Jack", DateOfBirth = new DateTime(1972, 5, 2) },
                new Person { LastName = "Smith", FirstName = "Jane", DateOfBirth = new DateTime(1987, 11, 22) },
                new Person { LastName = "Black", FirstName = "Bob", DateOfBirth = new DateTime(1953, 1, 31) },
                new Person { LastName = "Doe", FirstName = "John", DateOfBirth = new DateTime(1981, 9, 12) },
            };
            this.DataContext = this;
        }

        public List<Person> People { get; set; }
    }
}
